package com.cg.traineemgt.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemgt.dto.QueryMaster;
import com.cg.traineemgt.service.IQueryMasterService;

@Controller
public class QueryMasterController {
	@Autowired
	IQueryMasterService service;
	
	
	@RequestMapping(value="/ansqry")
	public ModelAndView checkQryId(@ModelAttribute("qry") QueryMaster qry,
			@RequestParam("query_id") int qid,
			 Model model)
	{
		model.addAttribute("query_id",qid);
		if(qid==1|| qid==2||qid==3||qid==4)
		{
			return new ModelAndView("updateSolution", "query_id", qry.getQuery_id());
		}
		else
		{
			return new ModelAndView("updatefailure", "query_id", qry.getQuery_id());
			
		}
		
	}
	
	

	
	@RequestMapping(value="updateSolution",method=RequestMethod.POST)
	public String updateData(@ModelAttribute("uu") QueryMaster qry) {
	service.updateSolution(qry.getQuery_id(),qry.getSolutions());
		return "updatesuccess";                                                                                                                                                                                                                            
	}

}
