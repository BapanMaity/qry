package com.cg.traineemgt.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service("service")
@Transactional
public class QueryMasterServiceImpl implements IQueryMasterService {

	
	@Autowired
	IQueryMasterService dao;
	@Override
	public void updateSolution(int qid, String solution) {
		dao.updateSolution(qid, solution);
		

	}

}
