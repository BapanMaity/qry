package com.cg.traineemgt.service;

public interface IQueryMasterService {
	
	public void updateSolution(int qid, String solution);

}
