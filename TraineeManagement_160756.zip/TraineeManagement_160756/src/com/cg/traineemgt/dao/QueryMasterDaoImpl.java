package com.cg.traineemgt.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository("dao")
public class QueryMasterDaoImpl implements IQueryMasterDao {

	
	@PersistenceContext
	EntityManager em;
	@Override
	public void updateSolution(int qid, String solution) {
		Query query=em.createQuery("UPDATE QueryMaster set "
				+ "solutions=:solution WHERE query_id=:qid");
		query.setParameter("qid", qid);
		query.setParameter("solution", solution);
		query.executeUpdate();

	}

}
