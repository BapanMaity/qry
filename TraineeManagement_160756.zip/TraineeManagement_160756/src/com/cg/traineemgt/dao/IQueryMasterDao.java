package com.cg.traineemgt.dao;

public interface IQueryMasterDao {
	public void updateSolution(int qid, String solution);

}
